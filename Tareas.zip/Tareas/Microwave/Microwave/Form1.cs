﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Microwave
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Timer vTime = new Timer();

        string vInputTime = "";
        
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (vTime.getTimer() == 1)
            {
                vTime.decreaseTimer();
                lblTimer.Text = $"{vTime.vHour:D2}:{vTime.vMinute:D2}:{vTime.vSecond:D2}";
                panel1.BackColor = Color.White;
                vTime.clearTimer();
                timer1.Enabled = false;
            }
            else 
            {
                vTime.decreaseTimer();
                lblTimer.Text = $"{vTime.vHour:D2}:{vTime.vMinute:D2}:{vTime.vSecond:D2}";
                panel1.BackColor = Color.Yellow;
            }
            
        }

        private void btnIniciar_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }
        private void btnReiniciar_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            vTime.clearTimer();
            lblTimer.Text = $"{vTime.vHour:D2}:{vTime.vMinute:D2}:{vTime.vSecond:D2}";
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            vTime.addTime(1);
            lblTimer.Text = $"{vTime.vHour:D2}:{vTime.vMinute:D2}:{vTime.vSecond:D2}";
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            vTime.addTime(2);
            lblTimer.Text = $"{vTime.vHour:D2}:{vTime.vMinute:D2}:{vTime.vSecond:D2}";
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            vTime.addTime(3);
            lblTimer.Text = $"{vTime.vHour:D2}:{vTime.vMinute:D2}:{vTime.vSecond:D2}";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            vTime.addTime(4);
            lblTimer.Text = $"{vTime.vHour:D2}:{vTime.vMinute:D2}:{vTime.vSecond:D2}";

        }

        private void btn5_Click(object sender, EventArgs e)
        {
            vTime.addTime(5);
            lblTimer.Text = $"{vTime.vHour:D2}:{vTime.vMinute:D2}:{vTime.vSecond:D2}";

        }

        private void btn6_Click(object sender, EventArgs e)
        {
            vTime.addTime(6);
            lblTimer.Text = $"{vTime.vHour:D2}:{vTime.vMinute:D2}:{vTime.vSecond:D2}";

        }

        private void btn_Click(object sender, EventArgs e)
        {
            vTime.addTime(7);
            lblTimer.Text = $"{vTime.vHour:D2}:{vTime.vMinute:D2}:{vTime.vSecond:D2}";

        }

        private void btn8_Click(object sender, EventArgs e)
        {
            vTime.addTime(8);
            lblTimer.Text = $"{vTime.vHour:D2}:{vTime.vMinute:D2}:{vTime.vSecond:D2}";

        }

        private void btn9_Click(object sender, EventArgs e)
        {

            vTime.addTime(9);
            lblTimer.Text = $"{vTime.vHour:D2}:{vTime.vMinute:D2}:{vTime.vSecond:D2}";
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            vTime.addTime(0);
            lblTimer.Text = $"{vTime.vHour:D2}:{vTime.vMinute:D2}:{vTime.vSecond:D2}";

        }

        
    }
}
