﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microwave
{
    internal class Timer
    {
        private double vContador = 0;
        private Int64 vTimerS = 0;
        public Int64 vSecond = 0;
        public Int64 vMinute = 0;
        public Int64 vHour = 0;
        private Int64 var1;
        private Int64 var2;
        private Int64 var3;
        private Int64 var4;
        private Int64 var5;
        

        //Metodo para obtener en numero lo ingresado por el usuario
        public void addTime(Int64 valor)
        {
            if (valor == 0 && vContador == 0)
            { }
            else
            {
                if (vTimerS < 32400)
                {

                    switch (vContador)
                    {
                        case 0:
                            var1 = valor;
                            vTimerS += valor;
                            break;
                        case 1:
                            var2 = valor;
                            vTimerS = (vTimerS * 10) + valor;
                            break;
                        case 2:
                            var3 = valor;
                            vTimerS = ((vTimerS / 10) * 60) + ((vTimerS % 10) * 10) + valor;
                            break;
                        case 3:
                            var4 = valor;
                            vTimerS = (((var1 * 10) + var2) * 60) + (var3 * 10) + valor;
                            break;
                        case 4:
                            var5 = valor;
                            vTimerS = (var1 * 3600) + (((var2 * 10) + var3) * 60) + (var4 * 10) + valor;
                            break;
                        case 5:
                            vTimerS = (((var1 * 10) + var2) * 3600) + (((var3 * 10) + var4) * 60) + (var5 * 10) + valor;
                            break;
                    }
                }
                vContador++;
            }
            formatTime();
        }

        public void formatTime()
        {
            if (vTimerS > 32400) // Ensure the timer doesn't exceed 9 hours (32400 seconds)
                vTimerS = 32400;

            vHour = vTimerS / 3600; // Calculate hours
            long remainingSeconds = vTimerS % 3600; // Calculate remaining seconds after subtracting hours
            vMinute = remainingSeconds / 60; // Calculate minutes from remaining seconds
            vSecond = remainingSeconds % 60; // Calculate remaining seconds after subtracting minutes
        }



        public Int64 getTimer() 
        {
            return vTimerS;
        }
        
        //Method for the timer to decrease the time

        public void decreaseTimer()
        {
            if(vTimerS > 0) vTimerS--;
            formatTime();
        }

        //Method to clear everything when clicking reiniciar
        public void clearTimer()
        {
            vContador = 0;
            vTimerS = 0;
            vSecond = 0;
            vMinute = 0;
            vHour = 0;

        }
        
        ////Methods to set seconds, minutes and hours
        //private void setSeconds(string seconds) 
        //{
        //    if (Convert.ToInt32(seconds) > 60)
        //    {
        //        vSecond = Convert.ToInt32(seconds) % 60;
        //        vMinute += Convert.ToInt32(seconds) / 60;
        //    }
        //    else
        //    {
        //        vSecond = Convert.ToInt32(seconds);
        //    }
        //}

        //private void setMinutes(string seconds, string minutes) 
        //{
        //    if (minutes != null)
        //    {
                
        //        if (Convert.ToInt32(minutes) > 60)
        //        {
        //            vMinute = Convert.ToInt32(minutes) % 60;
        //            vHour += Convert.ToInt32(minutes) / 60;
        //        }
        //        else
        //        {
        //            vMinute = Convert.ToInt32(minutes);
        //        }
        //    }
        //    else 
        //    {
        //        setSeconds(seconds);
        //        vMinute = 0;
        //    }
            
        //}

        //private void setHours(string hours) 
        //{
        //    if(hours != null) vHour = Convert.ToInt32(hours);
        //    else vHour = 0;
        //}

    }
}
