﻿namespace StudentGrade
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            btnAdd = new Button();
            rbnDislike = new RadioButton();
            rbnLike = new RadioButton();
            cmbFoods = new ComboBox();
            groupBox2 = new GroupBox();
            lstResults = new ListBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnAdd);
            groupBox1.Controls.Add(rbnDislike);
            groupBox1.Controls.Add(rbnLike);
            groupBox1.Controls.Add(cmbFoods);
            groupBox1.Location = new Point(18, 8);
            groupBox1.Margin = new Padding(4, 3, 4, 3);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4, 3, 4, 3);
            groupBox1.Size = new Size(651, 95);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Vote";
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(486, 33);
            btnAdd.Margin = new Padding(4, 3, 4, 3);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(149, 26);
            btnAdd.TabIndex = 3;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // rbnDislike
            // 
            rbnDislike.AutoSize = true;
            rbnDislike.Location = new Point(359, 34);
            rbnDislike.Margin = new Padding(4, 3, 4, 3);
            rbnDislike.Name = "rbnDislike";
            rbnDislike.Size = new Size(74, 19);
            rbnDislike.TabIndex = 2;
            rbnDislike.TabStop = true;
            rbnDislike.Text = "Dislike";
            rbnDislike.UseVisualStyleBackColor = true;
            // 
            // rbnLike
            // 
            rbnLike.AutoSize = true;
            rbnLike.Location = new Point(245, 34);
            rbnLike.Margin = new Padding(4, 3, 4, 3);
            rbnLike.Name = "rbnLike";
            rbnLike.Size = new Size(53, 19);
            rbnLike.TabIndex = 1;
            rbnLike.TabStop = true;
            rbnLike.Text = "Like";
            rbnLike.UseVisualStyleBackColor = true;
            // 
            // cmbFoods
            // 
            cmbFoods.FormattingEnabled = true;
            cmbFoods.Location = new Point(8, 33);
            cmbFoods.Margin = new Padding(4, 3, 4, 3);
            cmbFoods.Name = "cmbFoods";
            cmbFoods.Size = new Size(204, 23);
            cmbFoods.TabIndex = 0;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lstResults);
            groupBox2.Location = new Point(20, 118);
            groupBox2.Margin = new Padding(4, 3, 4, 3);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(4, 3, 4, 3);
            groupBox2.Size = new Size(648, 217);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Results";
            // 
            // lstResults
            // 
            lstResults.FormattingEnabled = true;
            lstResults.ItemHeight = 15;
            lstResults.Location = new Point(20, 29);
            lstResults.Margin = new Padding(4, 3, 4, 3);
            lstResults.Name = "lstResults";
            lstResults.Size = new Size(613, 169);
            lstResults.TabIndex = 0;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Font = new Font("Courier New", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(4, 3, 4, 3);
            Name = "Form1";
            Text = "Food Survey";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Button btnAdd;
        private RadioButton rbnDislike;
        private RadioButton rbnLike;
        private ComboBox cmbFoods;
        private GroupBox groupBox2;
        private ListBox lstResults;
    }
}
