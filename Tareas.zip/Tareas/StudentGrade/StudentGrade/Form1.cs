namespace StudentGrade
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Arreglo unidimensional para almacenar las opciones de comida
        string[] foods = { "Pizza de Queso".PadRight(20,' '), "Hamburguesas".PadRight(20, ' '), "Empanadas".PadRight(20, ' '), "Tacos".PadRight(20, ' ') };

        //arreglo multidimensional
        int[,] resultados = new int[4, 2];

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbFoods.DataSource = foods;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Limpiamos el listbox y mostramos la cabecera
            lstResults.Items.Clear();
            //Agregamos la cabecera
            lstResults.Items.Add("Food\t\t\tLike\t\t\tDislike");

            //Capturar el elemento seleccionado
            int index = cmbFoods.SelectedIndex;

            //Vamos a recorrer nuestro arreglo foods y determinar
            //Si el usuario eligio "Like" o "Dislike"

            for (int row = 0; row < foods.Length; row++)
            {
                //Revisa si el usuario marco me gusta o no me gusta
                if (rbnLike.Checked && index == row)
                {
                    resultados[row, 0]++;
                }
                else if (rbnDislike.Checked && index == row)
                {
                    resultados[row, 1]++;
                }

                //Mostramos la salida
                lstResults.Items.Add(
                    foods[row] + "\t\t"
                    + resultados[row, 0] + "\t\t\t"
                    + resultados[row, 1]
                    );
            }

        }



    }
}
