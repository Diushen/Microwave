namespace Listas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Anadir un elemento a la lista
            //listBox1.Items.Add("Jorge Perez");

            //Insertar un elemento a la lista
            //listBox1.Items.Insert(0, "Adela");

            //Borrar un elemento de la lista
            //listBox1.Items.Remove("sd");
            //listBox1.Items.RemoveAt(3);

            //Limpiae la lista
            //listBox1.Items.Clear();

            //Cuantos elementos hay en la lista
            MessageBox.Show(listBox1.Items.Count.ToString());

            //Recorrer una lista
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                MessageBox.Show(listBox1.Items[i].ToString());
            }

            foreach (var item in listBox1.Items)
            {
                MessageBox.Show(item.ToString());
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Saber que elemento selecciono un usuario

            MessageBox.Show(listBox1.SelectedIndex.ToString());
            MessageBox.Show(listBox1.SelectedItem.ToString());
            for (var i = 0; i < listBox1.Items.Count; i++)
            {
                if (listBox1.GetSelected(i))
                {
                    
                }
            }

            foreach (var item in listBox1.SelectedItems)
            {
                
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show(listBox1.SelectedItem.ToString());


        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                listBox1.Enabled = false;
            }
        }
    }
}
