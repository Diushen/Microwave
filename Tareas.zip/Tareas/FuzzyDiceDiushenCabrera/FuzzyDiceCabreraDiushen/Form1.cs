namespace FuzzyDiceCabreraDiushen
{
    public partial class Form1 : Form
    {
        //variables para almacenar datos
        uint wbQuantity = 0;
        uint rbQuantity = 0;
        uint bbQuantity = 0;
        uint diceQuantity;

        //Datos de precios
        const double wbPrice = 6.25;
        const double rbPrice = 5.00;
        const double bbPrice = 7.50;
        double shipping = 1.50;

        //Variables para totales
        double wbTotal;
        double rbTotal;
        double bbTotal;
        double subtotal;
        double tax;
        double discount;
        double total;

        public Form1()
        {
            InitializeComponent();

            bnCalculate.Enabled = false;
            txtWBQuantity.Enabled = false;
            txtRBQuantity.Enabled = false;
            txtBBQuantity.Enabled = false;

            lbWBPrice.Text = string.Format("{0:C}", wbPrice);
            lbRBPrice.Text = string.Format("{0:C}", rbPrice);
            lbBBPrice.Text = string.Format("{0:C}", bbPrice);

        }

        private void bnCalculate_Click(object sender, EventArgs e)
        {
            if (txtOrderNumber.Text == string.Empty || txtCustomerName.Text == string.Empty || txtStreetAddress.Text == string.Empty ||
                txtCityZipAddress.Text == string.Empty)
            {
                MessageBox.Show("You must enter the Order number, your name and address in order to calculate your order",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                if (txtWBQuantity.Text == string.Empty)
                {
                    txtWBQuantity.Text = "0";
                }

                if (txtRBQuantity.Text == string.Empty)
                {
                    txtRBQuantity.Text = "0";
                }

                if (txtBBQuantity.Text == string.Empty)
                {
                    txtBBQuantity.Text = "0";
                }

                wbQuantity = Convert.ToUInt32(txtWBQuantity.Text);
                rbQuantity = Convert.ToUInt32(txtRBQuantity.Text);
                bbQuantity = Convert.ToUInt32(txtBBQuantity.Text);

                diceQuantity = wbQuantity + rbQuantity + bbQuantity;

                if (diceQuantity > 20)
                {
                    shipping = 0;
                }

                wbTotal = wbQuantity * wbPrice;
                rbTotal = rbQuantity * rbPrice;
                bbTotal = bbQuantity * bbPrice;

                subtotal = wbTotal + rbTotal + bbTotal;

                if (subtotal > 500)
                {
                    discount = subtotal * 1.07;
                }

                tax = subtotal * 1.05;

                total = (subtotal + tax + shipping) - discount;

                txtWBTotal.Text = string.Format("{0:C}", wbTotal);
                txtRBTotal.Text = string.Format("{0:C}", rbTotal);
                txtBBTotal.Text = string.Format("{0:C}", bbTotal);

                txtSubtotalCharge.Text = string.Format("{0:C}", subtotal);
                txtShippingCharge.Text = string.Format("{0:C}", shipping);
                txtDiscountCharge.Text = string.Format("{0:C}", discount);
                txtTaxCharge.Text = string.Format("{0:C}", tax);
                txtTotalCharge.Text = string.Format("{0:C}", total);
                ;
            }
        }

        private void txtOrderNumber_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtWBQuantity_TextChanged(object sender, EventArgs e)
        {
            if (txtWBQuantity.Text.Length > 0 || txtRBQuantity.Text.Length > 0 || txtBBQuantity.Text.Length > 0)
            {
                bnCalculate.Enabled = true;
            }
            else
            {
                bnCalculate.Enabled = false;
            }

        }

        private void txtRBQuantity_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtBBQuantity_TextChanged(object sender, EventArgs e)
        {

        }

        private void chkWhiteBlack_CheckedChanged(object sender, EventArgs e)
        {
            if (chkWhiteBlack.Checked)
            {
                txtWBQuantity.Enabled = true;
            }
            else {
                txtWBQuantity.Enabled = false;
            }
        }

        private void chkRedBlack_CheckedChanged(object sender, EventArgs e)
        {
            if (chkRedBlack.Checked)
            {
                txtRBQuantity.Enabled = true;
            }
            else {
                txtRBQuantity.Enabled = false; ;
            }
        }

        private void chkBlueBlack_CheckedChanged(object sender, EventArgs e)
        {
            if (chkBlueBlack.Checked)
            {
                txtBBQuantity.Enabled = true;
            }
            else {
                txtBBQuantity.Enabled = false;
            }
        }
    }
}
