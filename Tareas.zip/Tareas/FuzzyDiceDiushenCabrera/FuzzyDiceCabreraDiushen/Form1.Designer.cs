﻿namespace FuzzyDiceCabreraDiushen
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            txtOrderNumber = new TextBox();
            txtCustomerName = new TextBox();
            txtStreetAddress = new TextBox();
            txtAddressLine2 = new TextBox();
            txtCityZipAddress = new TextBox();
            chkWhiteBlack = new CheckBox();
            chkRedBlack = new CheckBox();
            chkBlueBlack = new CheckBox();
            txtWBQuantity = new TextBox();
            txtRBQuantity = new TextBox();
            txtBBQuantity = new TextBox();
            lbWBPrice = new Label();
            lbRBPrice = new Label();
            lbBBPrice = new Label();
            txtWBTotal = new TextBox();
            txtRBTotal = new TextBox();
            txtBBTotal = new TextBox();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            txtSubtotalCharge = new TextBox();
            txtTaxCharge = new TextBox();
            txtShippingCharge = new TextBox();
            txtDiscountCharge = new TextBox();
            txtTotalCharge = new TextBox();
            bnCalculate = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(294, 20);
            label1.Name = "label1";
            label1.Size = new Size(161, 40);
            label1.TabIndex = 0;
            label1.Text = "Fuzzy Dice";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(34, 81);
            label2.Name = "label2";
            label2.Size = new Size(87, 15);
            label2.TabIndex = 1;
            label2.Text = "Order Number:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(34, 130);
            label3.Name = "label3";
            label3.Size = new Size(39, 15);
            label3.TabIndex = 2;
            label3.Text = "Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(34, 162);
            label4.Name = "label4";
            label4.Size = new Size(45, 15);
            label4.TabIndex = 3;
            label4.Text = "Adress:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(34, 294);
            label5.Name = "label5";
            label5.Size = new Size(34, 15);
            label5.TabIndex = 4;
            label5.Text = "Type:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(167, 294);
            label6.Name = "label6";
            label6.Size = new Size(56, 15);
            label6.TabIndex = 5;
            label6.Text = "Quantity:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(332, 294);
            label7.Name = "label7";
            label7.Size = new Size(36, 15);
            label7.TabIndex = 6;
            label7.Text = "Price:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(490, 294);
            label8.Name = "label8";
            label8.Size = new Size(46, 15);
            label8.TabIndex = 7;
            label8.Text = "Totales:";
            // 
            // txtOrderNumber
            // 
            txtOrderNumber.BackColor = SystemColors.Window;
            txtOrderNumber.Location = new Point(137, 73);
            txtOrderNumber.Name = "txtOrderNumber";
            txtOrderNumber.Size = new Size(100, 23);
            txtOrderNumber.TabIndex = 8;
            txtOrderNumber.TextAlign = HorizontalAlignment.Right;
            txtOrderNumber.TextChanged += txtOrderNumber_TextChanged;
            // 
            // txtCustomerName
            // 
            txtCustomerName.Location = new Point(137, 122);
            txtCustomerName.Name = "txtCustomerName";
            txtCustomerName.PlaceholderText = "Your name";
            txtCustomerName.Size = new Size(453, 23);
            txtCustomerName.TabIndex = 9;
            // 
            // txtStreetAddress
            // 
            txtStreetAddress.Location = new Point(137, 154);
            txtStreetAddress.Name = "txtStreetAddress";
            txtStreetAddress.PlaceholderText = "Street name and number";
            txtStreetAddress.Size = new Size(453, 23);
            txtStreetAddress.TabIndex = 10;
            // 
            // txtAddressLine2
            // 
            txtAddressLine2.Location = new Point(137, 183);
            txtAddressLine2.Name = "txtAddressLine2";
            txtAddressLine2.PlaceholderText = "Address line 2";
            txtAddressLine2.Size = new Size(453, 23);
            txtAddressLine2.TabIndex = 11;
            // 
            // txtCityZipAddress
            // 
            txtCityZipAddress.Location = new Point(137, 212);
            txtCityZipAddress.Name = "txtCityZipAddress";
            txtCityZipAddress.PlaceholderText = "City, State and Zip code";
            txtCityZipAddress.Size = new Size(453, 23);
            txtCityZipAddress.TabIndex = 12;
            // 
            // chkWhiteBlack
            // 
            chkWhiteBlack.AutoSize = true;
            chkWhiteBlack.Location = new Point(34, 336);
            chkWhiteBlack.Name = "chkWhiteBlack";
            chkWhiteBlack.Size = new Size(90, 19);
            chkWhiteBlack.TabIndex = 13;
            chkWhiteBlack.Text = "White/Black";
            chkWhiteBlack.UseVisualStyleBackColor = true;
            chkWhiteBlack.CheckedChanged += chkWhiteBlack_CheckedChanged;
            // 
            // chkRedBlack
            // 
            chkRedBlack.AutoSize = true;
            chkRedBlack.Location = new Point(34, 372);
            chkRedBlack.Name = "chkRedBlack";
            chkRedBlack.Size = new Size(79, 19);
            chkRedBlack.TabIndex = 14;
            chkRedBlack.Text = "Red/Black";
            chkRedBlack.UseVisualStyleBackColor = true;
            chkRedBlack.CheckedChanged += chkRedBlack_CheckedChanged;
            // 
            // chkBlueBlack
            // 
            chkBlueBlack.AutoSize = true;
            chkBlueBlack.Location = new Point(34, 410);
            chkBlueBlack.Name = "chkBlueBlack";
            chkBlueBlack.Size = new Size(82, 19);
            chkBlueBlack.TabIndex = 15;
            chkBlueBlack.Text = "Blue/Black";
            chkBlueBlack.UseVisualStyleBackColor = true;
            chkBlueBlack.CheckedChanged += chkBlueBlack_CheckedChanged;
            // 
            // txtWBQuantity
            // 
            txtWBQuantity.Location = new Point(167, 332);
            txtWBQuantity.Name = "txtWBQuantity";
            txtWBQuantity.Size = new Size(100, 23);
            txtWBQuantity.TabIndex = 16;
            txtWBQuantity.TextAlign = HorizontalAlignment.Right;
            txtWBQuantity.TextChanged += txtWBQuantity_TextChanged;
            // 
            // txtRBQuantity
            // 
            txtRBQuantity.Location = new Point(167, 368);
            txtRBQuantity.Name = "txtRBQuantity";
            txtRBQuantity.Size = new Size(100, 23);
            txtRBQuantity.TabIndex = 17;
            txtRBQuantity.TextAlign = HorizontalAlignment.Right;
            txtRBQuantity.TextChanged += txtRBQuantity_TextChanged;
            // 
            // txtBBQuantity
            // 
            txtBBQuantity.Location = new Point(167, 406);
            txtBBQuantity.Name = "txtBBQuantity";
            txtBBQuantity.Size = new Size(100, 23);
            txtBBQuantity.TabIndex = 18;
            txtBBQuantity.TextAlign = HorizontalAlignment.Right;
            txtBBQuantity.TextChanged += txtBBQuantity_TextChanged;
            // 
            // lbWBPrice
            // 
            lbWBPrice.AutoSize = true;
            lbWBPrice.Location = new Point(332, 336);
            lbWBPrice.Name = "lbWBPrice";
            lbWBPrice.Size = new Size(10, 15);
            lbWBPrice.TabIndex = 19;
            lbWBPrice.Text = " ";
            // 
            // lbRBPrice
            // 
            lbRBPrice.AutoSize = true;
            lbRBPrice.Location = new Point(332, 371);
            lbRBPrice.Name = "lbRBPrice";
            lbRBPrice.Size = new Size(10, 15);
            lbRBPrice.TabIndex = 20;
            lbRBPrice.Text = " ";
            // 
            // lbBBPrice
            // 
            lbBBPrice.AutoSize = true;
            lbBBPrice.Location = new Point(332, 410);
            lbBBPrice.Name = "lbBBPrice";
            lbBBPrice.Size = new Size(10, 15);
            lbBBPrice.TabIndex = 21;
            lbBBPrice.Text = " ";
            // 
            // txtWBTotal
            // 
            txtWBTotal.BackColor = SystemColors.GradientInactiveCaption;
            txtWBTotal.Location = new Point(490, 332);
            txtWBTotal.Name = "txtWBTotal";
            txtWBTotal.Size = new Size(100, 23);
            txtWBTotal.TabIndex = 22;
            // 
            // txtRBTotal
            // 
            txtRBTotal.BackColor = SystemColors.GradientInactiveCaption;
            txtRBTotal.Location = new Point(490, 370);
            txtRBTotal.Name = "txtRBTotal";
            txtRBTotal.Size = new Size(100, 23);
            txtRBTotal.TabIndex = 23;
            // 
            // txtBBTotal
            // 
            txtBBTotal.BackColor = SystemColors.GradientInactiveCaption;
            txtBBTotal.Location = new Point(490, 406);
            txtBBTotal.Name = "txtBBTotal";
            txtBBTotal.Size = new Size(100, 23);
            txtBBTotal.TabIndex = 24;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(332, 466);
            label9.Name = "label9";
            label9.Size = new Size(54, 15);
            label9.TabIndex = 25;
            label9.Text = "Subtotal:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(332, 494);
            label10.Name = "label10";
            label10.Size = new Size(27, 15);
            label10.TabIndex = 26;
            label10.Text = "Tax:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(332, 522);
            label11.Name = "label11";
            label11.Size = new Size(57, 15);
            label11.TabIndex = 27;
            label11.Text = "Shipping:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(332, 552);
            label12.Name = "label12";
            label12.Size = new Size(60, 15);
            label12.TabIndex = 28;
            label12.Text = "Discount: ";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(332, 581);
            label13.Name = "label13";
            label13.Size = new Size(35, 15);
            label13.TabIndex = 29;
            label13.Text = "Total:";
            // 
            // txtSubtotalCharge
            // 
            txtSubtotalCharge.BackColor = SystemColors.GradientInactiveCaption;
            txtSubtotalCharge.Location = new Point(490, 458);
            txtSubtotalCharge.Name = "txtSubtotalCharge";
            txtSubtotalCharge.Size = new Size(100, 23);
            txtSubtotalCharge.TabIndex = 30;
            // 
            // txtTaxCharge
            // 
            txtTaxCharge.BackColor = SystemColors.GradientInactiveCaption;
            txtTaxCharge.Location = new Point(490, 486);
            txtTaxCharge.Name = "txtTaxCharge";
            txtTaxCharge.Size = new Size(100, 23);
            txtTaxCharge.TabIndex = 31;
            // 
            // txtShippingCharge
            // 
            txtShippingCharge.BackColor = SystemColors.GradientInactiveCaption;
            txtShippingCharge.Location = new Point(490, 514);
            txtShippingCharge.Name = "txtShippingCharge";
            txtShippingCharge.Size = new Size(100, 23);
            txtShippingCharge.TabIndex = 32;
            // 
            // txtDiscountCharge
            // 
            txtDiscountCharge.BackColor = SystemColors.GradientInactiveCaption;
            txtDiscountCharge.Location = new Point(490, 544);
            txtDiscountCharge.Name = "txtDiscountCharge";
            txtDiscountCharge.Size = new Size(100, 23);
            txtDiscountCharge.TabIndex = 33;
            // 
            // txtTotalCharge
            // 
            txtTotalCharge.BackColor = SystemColors.GradientInactiveCaption;
            txtTotalCharge.Location = new Point(490, 573);
            txtTotalCharge.Name = "txtTotalCharge";
            txtTotalCharge.Size = new Size(100, 23);
            txtTotalCharge.TabIndex = 34;
            // 
            // bnCalculate
            // 
            bnCalculate.Location = new Point(490, 618);
            bnCalculate.Name = "bnCalculate";
            bnCalculate.Size = new Size(100, 33);
            bnCalculate.TabIndex = 35;
            bnCalculate.Text = "Calculate";
            bnCalculate.UseVisualStyleBackColor = true;
            bnCalculate.Click += bnCalculate_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(664, 687);
            Controls.Add(bnCalculate);
            Controls.Add(txtTotalCharge);
            Controls.Add(txtDiscountCharge);
            Controls.Add(txtShippingCharge);
            Controls.Add(txtTaxCharge);
            Controls.Add(txtSubtotalCharge);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(txtBBTotal);
            Controls.Add(txtRBTotal);
            Controls.Add(txtWBTotal);
            Controls.Add(lbBBPrice);
            Controls.Add(lbRBPrice);
            Controls.Add(lbWBPrice);
            Controls.Add(txtBBQuantity);
            Controls.Add(txtRBQuantity);
            Controls.Add(txtWBQuantity);
            Controls.Add(chkBlueBlack);
            Controls.Add(chkRedBlack);
            Controls.Add(chkWhiteBlack);
            Controls.Add(txtCityZipAddress);
            Controls.Add(txtAddressLine2);
            Controls.Add(txtStreetAddress);
            Controls.Add(txtCustomerName);
            Controls.Add(txtOrderNumber);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private TextBox txtOrderNumber;
        private TextBox txtCustomerName;
        private TextBox txtStreetAddress;
        private TextBox txtAddressLine2;
        private TextBox txtCityZipAddress;
        private CheckBox chkWhiteBlack;
        private CheckBox chkRedBlack;
        private CheckBox chkBlueBlack;
        private TextBox txtWBQuantity;
        private TextBox txtRBQuantity;
        private TextBox txtBBQuantity;
        private Label lbWBPrice;
        private Label lbRBPrice;
        private Label lbBBPrice;
        private TextBox txtWBTotal;
        private TextBox txtRBTotal;
        private TextBox txtBBTotal;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private TextBox txtSubtotalCharge;
        private TextBox txtTaxCharge;
        private TextBox txtShippingCharge;
        private TextBox txtDiscountCharge;
        private TextBox txtTotalCharge;
        private Button bnCalculate;
    }
}
