using System.Drawing.Text;

namespace ProgrammersShoppingCart
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
            //Desabilitamos el boton purchase
            btnPurchase.Enabled = false;
            //haya un metodo de pago seleccionado por defecto
            rbnFullPayment.Checked = true;



        }

        private void chkCSEbook_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCSEbook.Checked == true || chkVBSchool.Checked == true || chkCForProgrammers.Checked == true)
            {
                btnPurchase.Enabled = true;
            }
            else
            {
                btnPurchase.Enabled = false;
            }
        }

        private void btnPurchase_Click(object sender, EventArgs e)
        {
            //vamos a declarar variables locales
            string message = "You purchased: \n\r\t";
            int amount = 0;
            string paymentMode = "Your payment mode is: ";

            //validamos cuales libros seleccion� el usuario
            if (chkCSEbook.Checked) {
                amount += 30;
                message += chkCSEbook.Text + "\n\r\t";
            }
            if (chkVBSchool.Checked) {
                amount += 40;
                message += chkVBSchool.Text + "\n\r\t";
            }
            if (chkCForProgrammers.Checked) {
                amount += 50;
                message += chkCForProgrammers.Text + "\n\r\t";
            }

            

            //Verificar el modo de pago seleccionado
            if (rbnFullPayment.Checked)
            {
                paymentMode = paymentMode + rbnFullPayment.Text;
            }
            else {
                paymentMode = paymentMode + rbnInstallments.Text;
            }

            message += "\n\n\r" + paymentMode + "\n";

            //Total de la orden
            message += "Total due is: " + string.Format("{0:C}", amount);
            message += "Total due is: " + string.Format("{0:C}", amount);

            //Verificar si hubo comentarios
            if (txtComments.TextLength > 0)
            {
                message += "\n\nYour comments to us are: " + txtComments.Text;
            }

            //Mostrar el resumen de la compra
            MessageBox.Show(message);
        }
    }
}
