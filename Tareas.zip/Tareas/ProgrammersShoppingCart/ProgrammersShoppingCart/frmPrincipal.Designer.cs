﻿namespace ProgrammersShoppingCart
{
    partial class frmPrincipal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            groupBox1 = new GroupBox();
            chkCForProgrammers = new CheckBox();
            chkVBSchool = new CheckBox();
            chkCSEbook = new CheckBox();
            groupBox2 = new GroupBox();
            rbnInstallments = new RadioButton();
            rbnFullPayment = new RadioButton();
            txtComments = new TextBox();
            label2 = new Label();
            btnPurchase = new Button();
            btnExit = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(152, 31);
            label1.Name = "label1";
            label1.Size = new Size(412, 40);
            label1.TabIndex = 0;
            label1.Text = "Programmer's shopping cart";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(chkCForProgrammers);
            groupBox1.Controls.Add(chkVBSchool);
            groupBox1.Controls.Add(chkCSEbook);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(12, 91);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(257, 136);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Available Books";
            // 
            // chkCForProgrammers
            // 
            chkCForProgrammers.AutoSize = true;
            chkCForProgrammers.Font = new Font("Segoe UI", 9F);
            chkCForProgrammers.Location = new Point(11, 96);
            chkCForProgrammers.Name = "chkCForProgrammers";
            chkCForProgrammers.Size = new Size(158, 19);
            chkCForProgrammers.TabIndex = 2;
            chkCForProgrammers.Text = "C For Programmers ($50)";
            chkCForProgrammers.UseVisualStyleBackColor = true;
            // 
            // chkVBSchool
            // 
            chkVBSchool.AutoSize = true;
            chkVBSchool.Font = new Font("Segoe UI", 9F);
            chkVBSchool.Location = new Point(11, 58);
            chkVBSchool.Name = "chkVBSchool";
            chkVBSchool.Size = new Size(108, 19);
            chkVBSchool.TabIndex = 1;
            chkVBSchool.Text = "VB School ($40)";
            chkVBSchool.UseVisualStyleBackColor = true;
            // 
            // chkCSEbook
            // 
            chkCSEbook.AutoSize = true;
            chkCSEbook.Font = new Font("Segoe UI", 9F);
            chkCSEbook.Location = new Point(11, 22);
            chkCSEbook.Name = "chkCSEbook";
            chkCSEbook.Size = new Size(137, 19);
            chkCSEbook.TabIndex = 0;
            chkCSEbook.Text = "C Sharp E-Book ($30)";
            chkCSEbook.UseVisualStyleBackColor = true;
            chkCSEbook.CheckedChanged += chkCSEbook_CheckedChanged;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(rbnInstallments);
            groupBox2.Controls.Add(rbnFullPayment);
            groupBox2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(388, 87);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(270, 140);
            groupBox2.TabIndex = 2;
            groupBox2.TabStop = false;
            groupBox2.Text = "Payment Mode";
            // 
            // rbnInstallments
            // 
            rbnInstallments.AutoSize = true;
            rbnInstallments.Font = new Font("Segoe UI", 9F);
            rbnInstallments.Location = new Point(6, 72);
            rbnInstallments.Name = "rbnInstallments";
            rbnInstallments.Size = new Size(89, 19);
            rbnInstallments.TabIndex = 1;
            rbnInstallments.TabStop = true;
            rbnInstallments.Text = "Installments";
            rbnInstallments.UseVisualStyleBackColor = true;
            // 
            // rbnFullPayment
            // 
            rbnFullPayment.AutoSize = true;
            rbnFullPayment.Font = new Font("Segoe UI", 9F);
            rbnFullPayment.Location = new Point(6, 36);
            rbnFullPayment.Name = "rbnFullPayment";
            rbnFullPayment.Size = new Size(94, 19);
            rbnFullPayment.TabIndex = 0;
            rbnFullPayment.TabStop = true;
            rbnFullPayment.Text = "Full Payment";
            rbnFullPayment.UseVisualStyleBackColor = true;
            // 
            // txtComments
            // 
            txtComments.Location = new Point(12, 282);
            txtComments.Multiline = true;
            txtComments.Name = "txtComments";
            txtComments.Size = new Size(257, 139);
            txtComments.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 254);
            label2.Name = "label2";
            label2.Size = new Size(125, 15);
            label2.TabIndex = 4;
            label2.Text = "Your Comments to us:";
            // 
            // btnPurchase
            // 
            btnPurchase.Location = new Point(388, 282);
            btnPurchase.Name = "btnPurchase";
            btnPurchase.Size = new Size(270, 59);
            btnPurchase.TabIndex = 5;
            btnPurchase.Text = "Purchase";
            btnPurchase.UseVisualStyleBackColor = true;
            btnPurchase.Click += btnPurchase_Click;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(388, 367);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(270, 54);
            btnExit.TabIndex = 6;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            // 
            // frmPrincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnExit);
            Controls.Add(btnPurchase);
            Controls.Add(label2);
            Controls.Add(txtComments);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Name = "frmPrincipal";
            Text = "Programmer's shopping cart";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private GroupBox groupBox1;
        private CheckBox chkCForProgrammers;
        private CheckBox chkVBSchool;
        private CheckBox chkCSEbook;
        private GroupBox groupBox2;
        private RadioButton rbnInstallments;
        private RadioButton rbnFullPayment;
        private TextBox txtComments;
        private Label label2;
        private Button btnPurchase;
        private Button btnExit;
    }
}
