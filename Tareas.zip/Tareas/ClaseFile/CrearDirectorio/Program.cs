﻿namespace CrearDirectorio
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Directory.CreateDirectory();
            //Directory.Delete();

            
        }
    }
}
