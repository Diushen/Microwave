﻿namespace ClaseFile
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numero;
            try 
            {

                //Como determinar si un archivo existe
                if (!File.Exists("C:\\Users\\admin\\Desktop\\INTEC\\Cuarto trimestre\\Desarrollo de Software II\\test\\test_1.txt"))
                {
                    File.Create("C:\\Users\\admin\\Desktop\\INTEC\\Cuarto trimestre\\Desarrollo de Software II\\test\\test_1.txt");
                }
                else 
                {
                    Console.WriteLine("El archivo ya existe");
                }
                //Eliminar un archivo
                //File.Delete("C:\\Users\\admin\\Desktop\\INTEC\\Cuarto trimestre\\Desarrollo de Software II\\test\\test_1.txt");

                File.Copy("C:\\Users\\admin\\Desktop\\INTEC\\Cuarto trimestre\\Desarrollo de Software II\\test\\test_1.txt", "C:\\Users\\admin\\Desktop\\INTEC\\Cuarto trimestre\\Desarrollo de Software II\\test\\test_2.txt");
                //File.Move();
               FileAttributes fat = File.GetAttributes("C:\\Users\\admin\\Desktop\\INTEC\\Cuarto trimestre\\Desarrollo de Software II\\test\\test_1.txt");
                fat.ToString();
            }
            catch (Exception error) 
            {
                
            }
            finally { }
        }
    }
}
