﻿namespace LeerEscribirArchivos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Escribir a un archivo
            if (File.Exists("C:\\Users\\admin\\Desktop\\INTEC\\Cuarto trimestre\\Desarrollo de Software II\\test\\test_1.txt"))
            {
                StreamWriter wr = new StreamWriter("C:\\Users\\admin\\Desktop\\INTEC\\Cuarto trimestre\\Desarrollo de Software II\\test\\test_1.txt");
                wr.Write("Esto es una linea");
                wr.Write("Esto es otra linea");
                wr.WriteLine("Ultima Linea");
                wr.Close();
            }

            //using (StreamWriter wr2 = new StreamWriter("C:\\Users\\admin\\Desktop\\INTEC\\Cuarto trimestre\\Desarrollo de Software II\\test\\test_1.txt"))
            //{
            //    wr2.WriteLine("Esto es una linea");
            //    wr2.WriteLine("Esto es otra linea");
            //}

            //Leer un archivo
            StreamReader rd = new StreamReader("C:\\Users\\admin\\Desktop\\INTEC\\Cuarto trimestre\\Desarrollo de Software II\\test\\test_1.txt");

            string linea;
            //linea = rd.ReadLine();
            //Console.WriteLine(linea);
            //rd.Close();

            linea = rd.ReadLine();

            while (linea != null)
            {
                Console.WriteLine(linea);
                linea = rd.ReadLine();
            }

            rd.Close();

        }
    }
}
