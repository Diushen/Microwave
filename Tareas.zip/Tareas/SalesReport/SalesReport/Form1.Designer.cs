﻿namespace SalesReport
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            btnSubmit = new Button();
            txtFridayInput = new TextBox();
            txtThursdayInput = new TextBox();
            txtWednesdayInput = new TextBox();
            txtTuesdayInput = new TextBox();
            txtMondayInput = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            txtItemName = new TextBox();
            label1 = new Label();
            label7 = new Label();
            lstItemizedSales = new ListBox();
            label8 = new Label();
            txtGrossSales = new TextBox();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnSubmit);
            groupBox1.Controls.Add(txtFridayInput);
            groupBox1.Controls.Add(txtThursdayInput);
            groupBox1.Controls.Add(txtWednesdayInput);
            groupBox1.Controls.Add(txtTuesdayInput);
            groupBox1.Controls.Add(txtMondayInput);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(txtItemName);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(21, 18);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(272, 465);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Item Input";
            // 
            // btnSubmit
            // 
            btnSubmit.Location = new Point(111, 361);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(130, 32);
            btnSubmit.TabIndex = 12;
            btnSubmit.Text = "Submit Item";
            btnSubmit.UseVisualStyleBackColor = true;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // txtFridayInput
            // 
            txtFridayInput.Location = new Point(141, 302);
            txtFridayInput.Name = "txtFridayInput";
            txtFridayInput.Size = new Size(100, 23);
            txtFridayInput.TabIndex = 11;
            txtFridayInput.TextChanged += txtItemName_TextChanged;
            // 
            // txtThursdayInput
            // 
            txtThursdayInput.Location = new Point(141, 250);
            txtThursdayInput.Name = "txtThursdayInput";
            txtThursdayInput.Size = new Size(100, 23);
            txtThursdayInput.TabIndex = 10;
            txtThursdayInput.TextChanged += txtItemName_TextChanged;
            // 
            // txtWednesdayInput
            // 
            txtWednesdayInput.Location = new Point(141, 200);
            txtWednesdayInput.Name = "txtWednesdayInput";
            txtWednesdayInput.Size = new Size(100, 23);
            txtWednesdayInput.TabIndex = 9;
            txtWednesdayInput.TextChanged += txtItemName_TextChanged;
            // 
            // txtTuesdayInput
            // 
            txtTuesdayInput.Location = new Point(141, 147);
            txtTuesdayInput.Name = "txtTuesdayInput";
            txtTuesdayInput.Size = new Size(100, 23);
            txtTuesdayInput.TabIndex = 8;
            txtTuesdayInput.TextChanged += txtItemName_TextChanged;
            // 
            // txtMondayInput
            // 
            txtMondayInput.Location = new Point(141, 99);
            txtMondayInput.Name = "txtMondayInput";
            txtMondayInput.Size = new Size(100, 23);
            txtMondayInput.TabIndex = 7;
            txtMondayInput.TextChanged += txtItemName_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(18, 310);
            label6.Name = "label6";
            label6.Size = new Size(42, 15);
            label6.TabIndex = 6;
            label6.Text = "Friday:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(18, 258);
            label5.Name = "label5";
            label5.Size = new Size(58, 15);
            label5.TabIndex = 5;
            label5.Text = "Thursday:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(18, 208);
            label4.Name = "label4";
            label4.Size = new Size(71, 15);
            label4.TabIndex = 4;
            label4.Text = "Wednesday:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(18, 155);
            label3.Name = "label3";
            label3.Size = new Size(53, 15);
            label3.TabIndex = 3;
            label3.Text = "Tuesday:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(18, 107);
            label2.Name = "label2";
            label2.Size = new Size(54, 15);
            label2.TabIndex = 2;
            label2.Text = "Monday:";
            // 
            // txtItemName
            // 
            txtItemName.Location = new Point(105, 46);
            txtItemName.Name = "txtItemName";
            txtItemName.Size = new Size(136, 23);
            txtItemName.TabIndex = 1;
            txtItemName.TextChanged += txtItemName_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(18, 49);
            label1.Name = "label1";
            label1.Size = new Size(34, 15);
            label1.TabIndex = 0;
            label1.Text = "Item:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(426, 36);
            label7.Name = "label7";
            label7.Size = new Size(84, 15);
            label7.TabIndex = 1;
            label7.Text = "Itemized Sales:";
            // 
            // lstItemizedSales
            // 
            lstItemizedSales.FormattingEnabled = true;
            lstItemizedSales.ItemHeight = 15;
            lstItemizedSales.Location = new Point(426, 64);
            lstItemizedSales.Name = "lstItemizedSales";
            lstItemizedSales.Size = new Size(621, 349);
            lstItemizedSales.TabIndex = 2;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(799, 468);
            label8.Name = "label8";
            label8.Size = new Size(68, 15);
            label8.TabIndex = 3;
            label8.Text = "Gross Sales:";
            // 
            // txtGrossSales
            // 
            txtGrossSales.BackColor = SystemColors.ScrollBar;
            txtGrossSales.Location = new Point(919, 460);
            txtGrossSales.Name = "txtGrossSales";
            txtGrossSales.Size = new Size(128, 23);
            txtGrossSales.TabIndex = 4;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1182, 588);
            Controls.Add(txtGrossSales);
            Controls.Add(label8);
            Controls.Add(lstItemizedSales);
            Controls.Add(label7);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Sales Report";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox txtItemName;
        private Label label1;
        private Button btnSubmit;
        private TextBox txtFridayInput;
        private TextBox txtThursdayInput;
        private TextBox txtWednesdayInput;
        private TextBox txtTuesdayInput;
        private TextBox txtMondayInput;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label7;
        private ListBox lstItemizedSales;
        private Label label8;
        private TextBox txtGrossSales;
    }
}
