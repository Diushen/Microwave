namespace SalesReport
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int itemsCounter = 0;

        string[] itemsNames = new string[10];

        int[,] itemsValues = new int[10, 5];

        int[] totals = {0,0,0,0,0,0,0,0,0,0};

        int totalGross = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            btnSubmit.Enabled = false;
        }

        private void txtItemName_TextChanged(object sender, EventArgs e)
        {
            if (txtItemName.Text != string.Empty)
            {
                if (txtMondayInput.Text != string.Empty && txtTuesdayInput.Text != string.Empty && txtWednesdayInput.Text != string.Empty && txtThursdayInput.Text.Length > 0
                    && txtFridayInput.Text != string.Empty)
                {
                    btnSubmit.Enabled = true;
                }
                else
                {
                    btnSubmit.Enabled = false;
                }
            }
            else
            {
                btnSubmit.Enabled = false;
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            lstItemizedSales.Items.Clear();

            if (itemsCounter > 9)
            {
                MessageBox.Show("The limit of items per week was reached",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                btnSubmit.Enabled = false;
            }
            else
            {

                itemsNames[itemsCounter] = txtItemName.Text;

                itemsValues[itemsCounter, 0] = Convert.ToInt32(txtMondayInput.Text);
                itemsValues[itemsCounter, 1] = Convert.ToInt32(txtTuesdayInput.Text);
                itemsValues[itemsCounter, 2] = Convert.ToInt32(txtWednesdayInput.Text);
                itemsValues[itemsCounter, 3] = Convert.ToInt32(txtThursdayInput.Text);
                itemsValues[itemsCounter, 4] = Convert.ToInt32(txtFridayInput.Text);

                for (int j = 0; j < 5; j++)
                {
                    totals[itemsCounter] += itemsValues[itemsCounter, j];
                }
                totalGross += totals[itemsCounter];

                int padFC = 25;
                int padOC = 15;

                lstItemizedSales.Items.Add("Name".PadRight(padFC, ' ') + "\t" + "Mond.".PadRight(padOC, ' ') + "\t" + "Tuesd.".PadRight(padOC, ' ') + "\t" + "Wenesd.".PadRight(padOC, ' ') + "\t" +
                    "Thurs.".PadRight(padOC, ' ') + "\t" + "Frid.".PadRight(padOC, ' ') + "\t" + "Total".PadRight(padFC, ' '));

                for (int m = 0; m <= itemsCounter; m++) {

                    lstItemizedSales.Items.Add(itemsNames[m].PadRight(padFC, ' ') + "\t" + itemsValues[m, 0].ToString("C").PadRight(padOC, ' ') + "\t" +
                    itemsValues[m, 1].ToString("C").PadRight(padOC, ' ') + "\t" + itemsValues[m, 2].ToString("C").PadRight(padOC, ' ') + "\t" +
                    itemsValues[m, 3].ToString("C").PadRight(padOC, ' ') + "\t" + itemsValues[m, 4].ToString("C").PadRight(padOC, ' ') + "\t" +
                    totals[m].ToString("C").PadRight(padFC, ' '));;

                }

                txtGrossSales.Text = totalGross.ToString("C").PadLeft(25, ' ');

                txtItemName.Text = string.Empty;
                txtMondayInput.Text = string.Empty;
                txtTuesdayInput.Text = string.Empty;
                txtWednesdayInput.Text = string.Empty;
                txtThursdayInput.Text = string.Empty;
                txtFridayInput.Text = string.Empty;

                itemsCounter++;
            }

            

        }

        
    }
}
