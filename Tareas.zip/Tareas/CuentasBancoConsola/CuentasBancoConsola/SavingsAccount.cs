﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CuentasBancoConsola
{
    internal class SavingsAccount : Account
    {
        private decimal intRate;

        public decimal IntRate {
            get { return intRate; }
            set {
                intRate = value;
            } }

        public SavingsAccount(string firstName, string lastName, decimal initialBalance, decimal interest)
        :base(firstName, lastName, initialBalance)
        {
            intRate = interest;
        }


        public decimal CalculateInterest()
        {
            return Balance * intRate;
        }

        //Reescribir una representacion de cadena del metodo ToString
        public override string ToString() =>
            $"Nombre: {FirstName} {LastName}\n" +
            $"Balance: {Balance}\n" +
            $"Interes: {IntRate}\n" +
            $"Interes Calculado: {CalculateInterest()}\n";

     
            

    }
}
