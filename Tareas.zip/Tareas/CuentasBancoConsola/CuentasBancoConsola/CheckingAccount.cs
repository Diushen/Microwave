﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CuentasBancoConsola
{
    internal class CheckingAccount : Account
    {
        decimal charge = 0;
        decimal totalCharges = 0;

        public CheckingAccount(string firstName, string lastName, decimal initialBalance, decimal chargeT)
        : base(firstName, lastName, initialBalance)
        {
            charge = chargeT;
        }

        public decimal Charge { 
            get{ return charge; }
            set { if (value >= 0) charge = value; } 
        }

        public decimal TotalCharges
        {
            get { return totalCharges; }
            set { if (value >= 0) totalCharges = value; }
        }

        public override void Credit(decimal value)
        {
            if (Balance + value - charge >= 0)
            {
                Balance = value - charge;
                TotalCharges += charge;
            }
            else
            {
                Console.WriteLine("No posee suficiente balance para realizar la transacción");
            }
        }

        public override void Debit(decimal value)
        {
            if ((Balance - value - charge) >= 0)
            {
                Balance =  value + charge;
                TotalCharges += charge;
            }
            else
            {
                Console.WriteLine("No posee suficiente balance para realizar la transacción");
            }
        }

        //Reescribir una representacion de cadena del metodo ToString
        public override string ToString() =>   
            $"Nombre: {FirstName} {LastName}\n" +
            $"Balance: {Balance}\n" +
            $"Cargo por transaccion: {Charge}\n" +
            $"Total de Cargos por Transacciones: {TotalCharges}\n";

    }
}
