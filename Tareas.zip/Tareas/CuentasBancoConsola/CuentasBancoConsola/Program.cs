﻿
namespace CuentasBancoConsola
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Cuenta de Ahorros");
            SavingsAccount cuenta1 = new SavingsAccount("Juan", "Perez", 600.00M, 0.08M);
            Console.WriteLine("Datos de la cuenta Iniciales");
            Console.WriteLine(cuenta1.ToString());
            Console.WriteLine("Se realiza un Credito de 100\n");
            cuenta1.Credit(100);
            Console.WriteLine("Nuevos Datos por el credito");
            Console.WriteLine(cuenta1.ToString());
            Console.WriteLine("\nSe realiza un Debito por 800 que no se realizará porque excede el monto");
            cuenta1.Debit(800);
            Console.WriteLine("Ahora vemos la cuenta de nuevo");
            Console.WriteLine(cuenta1.ToString());
            Console.WriteLine("Agregamos el interes generado");
            cuenta1.Credit(cuenta1.CalculateInterest());
            Console.WriteLine(cuenta1.ToString());

            Console.WriteLine("\nCuenta Corriente");
            CheckingAccount cuenta2 = new CheckingAccount("Pedro", "Martinez", 2000.00M, 15.00M);
            Console.WriteLine("Datos de la cuenta Iniciales");
            Console.WriteLine(cuenta2.ToString());
            Console.WriteLine("Se realiza un Credito de 500\n");
            cuenta2.Credit(500);
            Console.WriteLine("\nNuevos Datos por el credito");
            Console.WriteLine(cuenta2.ToString());
            Console.WriteLine("Se realiza un Debito por 3000 que no se realizará porque excede el monto");
            cuenta2.Debit(3000);
            Console.WriteLine("Ahora vemos la cuenta de nuevo");
            Console.WriteLine(cuenta2.ToString());

        }
    }
}
