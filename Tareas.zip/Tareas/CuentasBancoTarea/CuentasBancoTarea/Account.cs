﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CuentasBancoTarea
{
    internal class Account
    {
        private decimal balance = 0;
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public decimal Balance {
            get { return balance; }

            set 
            {
                if (value < 0)
                {
                    MessageBox.Show("El balance no puede ser menor que cero");
                }
                else 
                {
                    balance += value;
                }
            } 
        
        }

        public Account(string firstName, string lastName, decimal initialBalance) 
        {
            FirstName = firstName;
            LastName = lastName;
            Balance = initialBalance;
        }

        public virtual void Credit(decimal value) 
        {
            balance += value;
        }

        public virtual void Debit(decimal value) { 
            if ((Balance - value) < 0)
            {
                MessageBox.Show("El monto del débito excedió el monto de la cuenta");
            }
            else 
            {
                Balance = Balance - value;
            }
        }


    }
}
