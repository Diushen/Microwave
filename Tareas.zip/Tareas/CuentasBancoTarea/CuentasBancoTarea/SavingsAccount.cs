﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CuentasBancoTarea
{
    internal class SavingsAccount : Account
    {
        private decimal intRate;

        public SavingsAccount(string firstName, string lastName, decimal initialBalance, decimal interest) 
        :base(firstName, lastName, initialBalance)
        {
            intRate = interest;
        }

        public decimal CalculateInterest() 
        {
            return Balance * intRate;
        }

    }
}
