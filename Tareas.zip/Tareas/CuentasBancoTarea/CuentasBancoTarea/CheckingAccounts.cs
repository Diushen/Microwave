﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CuentasBancoTarea
{
    internal class CheckingAccounts : Account
    {
        decimal charge;

        public CheckingAccounts(string firstName, string lastName, decimal initialBalance, decimal chargeT) 
        :base(firstName, lastName, initialBalance)
        {
            charge = chargeT;
        }

        public override void Credit(decimal value)
        {
            if ((Balance + value - charge) >= 0) 
            {
                Balance = Balance + value - charge;
            }
            else 
            {
                MessageBox.Show("No posee suficiente balance para realizar la transacción");
            }
        }

        public override void Debit(decimal value)
        {
            if ((Balance - value - charge) >= 0)
            {
                Balance = Balance - value - charge;
            }
            else
            {
                MessageBox.Show("No posee suficiente balance para realizar la transacción");
            }
        }

    }
}
