using System.Linq;

namespace ShippingHub
{
    public partial class Form1 : Form
    {
        private List<Package> packagesList; //Lista de paquetes
        private Package objPackage; //objeto paquete actual
        private int packagePosition; //posicion de un paquete
        private Random rndNumber; //generar los ID's
        private int packageNumber; //numero de un paquete
        string[] states = { "Alabama", "Florida", "Georgia", "Kentucky", "Mississippi", "North Carolina", "South Carolina", "Tennessee", "West Virginia", "Virginia" };
        public Form1()
        {
            InitializeComponent();
            btnBack.Enabled = false;
            btnEdit.Enabled = false;
            btnAdd.Enabled = false;
            btnRemove.Enabled = false;
            btnNext.Enabled = false;
            groupBox1.Enabled = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Boton next
            //Primero chequearemos si la lista de packages de un estado en especifico tiene solo ese elemento o mas
            if (/*lstPackages.Items[lstPackages.SelectedIndex + 1] != null &&*/ lstPackages.Items.Count - 1 > lstPackages.SelectedIndex)
            {
                //lstPackages.Items.Count > lstPackages.SelectedIndex)
                //Variable que dira el lugar del paquete actual

                int posActual = lstPackages.SelectedIndex;

                int numPack = Convert.ToInt32(lstPackages.Items[posActual + 1].ToString());

                foreach (Package item in packagesList)
                {
                    if (item.PackageNumber == numPack)
                    {
                        LoadPackage(item);
                        lstPackages.SelectedItem = numPack;
                    }
                }

            }
            else
            {
                //Primeros nos aseguramos de que la lista de paquetes tenga m�s de un paquete
                if (packagesList.Count > 1)
                {

                    int packageNumberV = Convert.ToInt32(lstPackages.SelectedItem);

                    //Ahora nos aseguramos de que hayan mas elementos delante del que tenemos seleccionado actualmente
                    for (int i = 0; i < packagesList.Count; i++)
                    {
                        if (packagesList[i].PackageNumber == packageNumberV)
                        {
                            if (packagesList.Count - 1 > i)
                            {
                                LoadPackage(packagesList[i + 1]);
                                cmbState.SelectedItem = packagesList[i + 1].PackageState;
                                lstPackages.SelectedItem = packagesList[i + 1].PackageNumber;
                            }
                            else
                            {
                                if (packagesList[0].PackageNumber != packagesList[i].PackageNumber)
                                {
                                    cmbState.SelectedItem = packagesList[0].PackageState;
                                    LoadPackage(packagesList[0]);
                                    lstPackages.SelectedItem = packagesList[0].PackageNumber;
                                }

                            }
                        }
                    }

                }

            }

        }

        private void LoadPackage(Package objPackage)
        {
            //Mostrar el paquete
            txtAddress.Text = objPackage.PackageAddress;
            txtCity.Text = objPackage.PackageCity;
            txtZipCode.Text = objPackage.PackageZip.ToString();
            lblArrivalTime.Text = objPackage.PackageDate.ToString();
            lblPackageNumber.Text = objPackage.PackageNumber.ToString();
            cmbViewPackage.SelectedItem = objPackage;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cmbState.DataSource = states;
            cmbState.SelectedIndex = 0;
            packagePosition = 0;
            rndNumber = new Random();
            packageNumber = rndNumber.Next(1, 1000000);

            //Creamos la lista de paquetes
            packagesList = new List<Package>();
        }

        private void btnScanNew_Click(object sender, EventArgs e)
        {
            //incrementa el ID
            packageNumber++;
            //Crear un nuevo paquete
            objPackage = new Package(packageNumber);

            //Debemos limpiar los controles
            clearControls();
            //Mostramos el ID del paquete y la fecha de registro
            lblPackageNumber.Text = objPackage.PackageNumber.ToString();
            lblArrivalTime.Text = objPackage.PackageDate.ToString();

            //Permitir al usuario a�adir un paquete
            groupBox1.Enabled = true;
            //Habilitar y deshabilitar botones
            btnAdd.Enabled = true;
            btnScanNew.Enabled = false;
            setButtons(false);
            txtAddress.Focus();
        }

        private void setButtons(bool state)
        {
            btnRemove.Enabled = state;
            btnEdit.Enabled = state;
            btnNext.Enabled = state;
            btnBack.Enabled = state;

            //Desabilitemos los botones de Next y Back si no hay mas paquetes
            //paquetes
            if (packagesList.Count < 1)
            {
                btnNext.Enabled = false;
                btnBack.Enabled = false;
            }

            //Si no hay paquetes, deshabilita los botones de Remove y Edit
            if (packagesList.Count == 0)
            {
                btnRemove.Enabled = false;
                btnEdit.Enabled = false;
            }

        }

        private void clearControls()
        {
            txtAddress.Clear();
            txtCity.Clear();
            txtZipCode.Clear();
            cmbState.SelectedText = "";
            lblArrivalTime.Text = "";
            lblPackageNumber.Text = "";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Asigne los atributos al objecto package
            setPackage();
            //A�adimos paquete a la lista
            packagesList.Add(objPackage);
            //Deshabilitar la edicion
            groupBox1.Enabled = false;
            //Habilitar los botones correspondientes
            setButtons(true);
            btnScanNew.Enabled = true;
            btnAdd.Enabled = false;


            if (cmbViewPackage.Text == cmbState.Text)
            {
                lstPackages.Items.Add(objPackage.PackageNumber);
            }

            cmbViewPackage.Text = objPackage.PackageState;
            btnScanNew.Enabled = true;

        }

        private void setPackage()
        {
            objPackage.PackageAddress = txtAddress.Text;
            objPackage.PackageCity = txtCity.Text;
            objPackage.PackageZip = Convert.ToInt32(txtZipCode.Text);

            if (cmbState.SelectedIndex == -1)
            {
                objPackage.PackageState = cmbState.Items[0].ToString();
            }
            else
            {
                objPackage.PackageState = cmbState.SelectedItem.ToString();
            }

        }

        private void cmbViewPackage_SelectedIndexChanged(object sender, EventArgs e)
        {
            string state = cmbViewPackage.SelectedItem.ToString();
            //Limpiar la lista de paquetes
            lstPackages.Items.Clear();

            //Recorrer la lista de paquetes
            foreach (Package package in packagesList)
            {
                if (package.PackageState == state)
                {
                    //A�adir ese objeto a la lista
                    lstPackages.Items.Add(package.PackageNumber);
                }
            }

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (btnEdit.Text == "EDIT")
            {
                groupBox1.Enabled = true;
                setButtons(false);
                btnEdit.Enabled = true;
                //Cambia su texto a UPDATE
                btnEdit.Text = "UPDATE";
            }
            else
            {
                setPackage();
                cmbViewPackage.Text = objPackage.PackageState;
                groupBox1.Enabled = false;
                btnEdit.Text = "EDIT";
                setButtons(true);
            }
        }

        private void lstPackages_DoubleClick(object sender, EventArgs e)
        {
            string packageData = "";

            if (lstPackages.SelectedIndex != -1)
            {
                foreach (Package item in packagesList)
                {
                    if (item.PackageNumber == Convert.ToInt32(lstPackages.SelectedItem))
                    {
                        packageData += "Package " + item.PackageNumber
                            + "\r\nArrived at " + item.PackageDate.ToString()
                            + "\r\n Address: " + item.PackageAddress
                            + "\r\nCity: " + item.PackageCity
                            + "\r\nState: " + item.PackageState
                            + "\r\nZip: " + item.PackageZip.ToString("00000");
                    }
                }
            }
            else
            {
                packageData = "Please Select a Package";
            }
            MessageBox.Show(packageData);
        }

        private void lstPackages_SelectedIndexChanged(object sender, EventArgs e)
        {
            string id = lstPackages.SelectedItem.ToString();
            //Limpiar la lista de paquetes

            //Recorrer la lista de paquetes
            foreach (Package package in packagesList)
            {
                if (package.PackageNumber == Convert.ToInt32(id))
                {
                    LoadPackage(package);
                }
            }

        }

        private void lstPackages_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            //Capturamos el indice del paquete a borrar
            int indexNumber = packagesList.IndexOf(objPackage);

            //Eliminar del listbox el paquete que coincida con el estado visualizado
            if (cmbState.Text == cmbViewPackage.Text)
            {
                lstPackages.Items.Remove(objPackage.PackageNumber);
            }

            //Borramos el elemento de la lista
            packagesList.Remove(objPackage);

            //Cargar el siguiente paquete de la lista
            if (packagesList.Count > 0)
            {
                if (packagesList.Count <= indexNumber)
                {
                    objPackage = packagesList[indexNumber - 1];
                }
                else
                {
                    objPackage = packagesList[indexNumber];
                }

                //Llamar metodo LoadPackage() que cargue un paquete en la lista
                LoadPackage(objPackage);
            }
            else
            {
                clearControls();
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            //First we need to check that the listbox has more than one package and the one were we are is not the first one
            if (lstPackages.Items.Count > 1 && lstPackages.SelectedIndex != 0)
            {
                //We get the position of the package selected and go back one
                int posActual = lstPackages.SelectedIndex;

                int numPack = Convert.ToInt32(lstPackages.Items[posActual - 1].ToString());

                foreach (Package item in packagesList)
                {
                    if (item.PackageNumber == numPack)
                    {
                        LoadPackage(item);
                        lstPackages.SelectedItem = numPack;
                    }
                }
            }
            //Now if the selected item is the first one in the list box we check in the list of packages for packages before that one
            else 
            {
                //Primeros nos aseguramos de que la lista de paquetes tenga m�s de un paquete
                if (packagesList.Count > 1)
                {

                    int packageNumberV = Convert.ToInt32(lstPackages.SelectedItem);

                    //Ahora nos aseguramos de que hayan mas elementos delante del que tenemos seleccionado actualmente
                    for (int i = 0; i < packagesList.Count; i++)
                    {
                        if (packagesList[i].PackageNumber == packageNumberV)
                        {
                            if (i == 0)
                            {
                                LoadPackage(packagesList[packagesList.Count - 1]);
                                cmbState.SelectedItem = packagesList[packagesList.Count - 1].PackageState;
                                lstPackages.SelectedItem = packagesList[packagesList.Count - 1].PackageNumber;
                            }
                            else
                            {
                                
                                 cmbState.SelectedItem = packagesList[i - 1].PackageState;
                                 LoadPackage(packagesList[i - 1]);
                                 lstPackages.SelectedItem = packagesList[i - 1].PackageNumber;

                            }
                        }
                    }
                }
            }
            
        }
    }
}
