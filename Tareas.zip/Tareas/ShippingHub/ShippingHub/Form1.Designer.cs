﻿namespace ShippingHub
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lblArrivalTime = new Label();
            groupBox1 = new GroupBox();
            txtZipCode = new TextBox();
            label6 = new Label();
            cmbState = new ComboBox();
            txtCity = new TextBox();
            label5 = new Label();
            label4 = new Label();
            txtAddress = new TextBox();
            label3 = new Label();
            lblPackageNumber = new Label();
            label2 = new Label();
            btnBack = new Button();
            btnScanNew = new Button();
            btnAdd = new Button();
            btnRemove = new Button();
            btnEdit = new Button();
            btnNext = new Button();
            groupBox2 = new GroupBox();
            lstPackages = new ListBox();
            cmbViewPackage = new ComboBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Tahoma", 9.75F);
            label1.Location = new Point(24, 49);
            label1.Name = "label1";
            label1.Size = new Size(69, 16);
            label1.TabIndex = 0;
            label1.Text = "Arrived At:";
            // 
            // lblArrivalTime
            // 
            lblArrivalTime.BorderStyle = BorderStyle.Fixed3D;
            lblArrivalTime.Font = new Font("Tahoma", 9.75F);
            lblArrivalTime.Location = new Point(168, 25);
            lblArrivalTime.Name = "lblArrivalTime";
            lblArrivalTime.Size = new Size(449, 39);
            lblArrivalTime.TabIndex = 1;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtZipCode);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(cmbState);
            groupBox1.Controls.Add(txtCity);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(txtAddress);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(lblPackageNumber);
            groupBox1.Controls.Add(label2);
            groupBox1.Font = new Font("Tahoma", 9.75F);
            groupBox1.Location = new Point(24, 90);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(741, 224);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Package Information";
            // 
            // txtZipCode
            // 
            txtZipCode.Location = new Point(598, 140);
            txtZipCode.MaxLength = 5;
            txtZipCode.Name = "txtZipCode";
            txtZipCode.Size = new Size(100, 23);
            txtZipCode.TabIndex = 9;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(551, 148);
            label6.Name = "label6";
            label6.Size = new Size(29, 16);
            label6.TabIndex = 8;
            label6.Text = "Zip:";
            // 
            // cmbState
            // 
            cmbState.FormattingEnabled = true;
            cmbState.Location = new Point(388, 140);
            cmbState.Name = "cmbState";
            cmbState.Size = new Size(140, 24);
            cmbState.TabIndex = 7;
            // 
            // txtCity
            // 
            txtCity.Location = new Point(144, 131);
            txtCity.Multiline = true;
            txtCity.Name = "txtCity";
            txtCity.Size = new Size(180, 32);
            txtCity.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(346, 148);
            label5.Name = "label5";
            label5.Size = new Size(42, 16);
            label5.TabIndex = 5;
            label5.Text = "State:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(19, 148);
            label4.Name = "label4";
            label4.Size = new Size(33, 16);
            label4.TabIndex = 4;
            label4.Text = "City:";
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(144, 75);
            txtAddress.Multiline = true;
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(574, 32);
            txtAddress.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(19, 92);
            label3.Name = "label3";
            label3.Size = new Size(58, 16);
            label3.TabIndex = 2;
            label3.Text = "Address:";
            // 
            // lblPackageNumber
            // 
            lblPackageNumber.BorderStyle = BorderStyle.Fixed3D;
            lblPackageNumber.Location = new Point(144, 24);
            lblPackageNumber.Name = "lblPackageNumber";
            lblPackageNumber.Size = new Size(574, 34);
            lblPackageNumber.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(19, 24);
            label2.Name = "label2";
            label2.Size = new Size(75, 16);
            label2.TabIndex = 0;
            label2.Text = "Package ID:";
            // 
            // btnBack
            // 
            btnBack.Font = new Font("Tahoma", 9.75F);
            btnBack.Location = new Point(25, 384);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(93, 41);
            btnBack.TabIndex = 10;
            btnBack.Text = "<BACK";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // btnScanNew
            // 
            btnScanNew.Font = new Font("Tahoma", 9.75F);
            btnScanNew.Location = new Point(150, 384);
            btnScanNew.Name = "btnScanNew";
            btnScanNew.Size = new Size(93, 41);
            btnScanNew.TabIndex = 11;
            btnScanNew.Text = "SCAN NEW";
            btnScanNew.UseVisualStyleBackColor = true;
            btnScanNew.Click += btnScanNew_Click;
            // 
            // btnAdd
            // 
            btnAdd.Font = new Font("Tahoma", 9.75F);
            btnAdd.Location = new Point(272, 384);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(93, 41);
            btnAdd.TabIndex = 12;
            btnAdd.Text = "ADD";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnRemove
            // 
            btnRemove.Font = new Font("Tahoma", 9.75F);
            btnRemove.Location = new Point(396, 384);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(93, 41);
            btnRemove.TabIndex = 13;
            btnRemove.Text = "REMOVE";
            btnRemove.UseVisualStyleBackColor = true;
            btnRemove.Click += btnRemove_Click;
            // 
            // btnEdit
            // 
            btnEdit.Font = new Font("Tahoma", 9.75F);
            btnEdit.Location = new Point(524, 384);
            btnEdit.Name = "btnEdit";
            btnEdit.Size = new Size(93, 41);
            btnEdit.TabIndex = 14;
            btnEdit.Text = "EDIT";
            btnEdit.UseVisualStyleBackColor = true;
            btnEdit.Click += btnEdit_Click;
            // 
            // btnNext
            // 
            btnNext.Font = new Font("Tahoma", 9.75F);
            btnNext.Location = new Point(649, 384);
            btnNext.Name = "btnNext";
            btnNext.Size = new Size(93, 41);
            btnNext.TabIndex = 15;
            btnNext.Text = "NEXT>";
            btnNext.UseVisualStyleBackColor = true;
            btnNext.Click += button6_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lstPackages);
            groupBox2.Controls.Add(cmbViewPackage);
            groupBox2.Font = new Font("Tahoma", 9.75F);
            groupBox2.Location = new Point(812, 90);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(334, 335);
            groupBox2.TabIndex = 16;
            groupBox2.TabStop = false;
            groupBox2.Text = "Packages by State";
            // 
            // lstPackages
            // 
            lstPackages.FormattingEnabled = true;
            lstPackages.Location = new Point(23, 92);
            lstPackages.Name = "lstPackages";
            lstPackages.Size = new Size(292, 228);
            lstPackages.TabIndex = 1;
            lstPackages.MouseClick += lstPackages_MouseClick;
            lstPackages.SelectedIndexChanged += lstPackages_SelectedIndexChanged;
            lstPackages.DoubleClick += lstPackages_DoubleClick;
            // 
            // cmbViewPackage
            // 
            cmbViewPackage.FormattingEnabled = true;
            cmbViewPackage.Items.AddRange(new object[] { "Alabama", "Florida", "Georgia", "Kentucky", "Mississippi", "North Carolina", "South Carolina", "Tennessee", "West Virginia", "Virginia" });
            cmbViewPackage.Location = new Point(15, 39);
            cmbViewPackage.Name = "cmbViewPackage";
            cmbViewPackage.Size = new Size(300, 24);
            cmbViewPackage.TabIndex = 0;
            cmbViewPackage.SelectedIndexChanged += cmbViewPackage_SelectedIndexChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1174, 450);
            Controls.Add(groupBox2);
            Controls.Add(btnNext);
            Controls.Add(btnEdit);
            Controls.Add(groupBox1);
            Controls.Add(btnRemove);
            Controls.Add(lblArrivalTime);
            Controls.Add(btnAdd);
            Controls.Add(label1);
            Controls.Add(btnScanNew);
            Controls.Add(btnBack);
            Name = "Form1";
            Text = "Shipping Hub App";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label lblArrivalTime;
        private GroupBox groupBox1;
        private Label label5;
        private Label label4;
        private TextBox txtAddress;
        private Label label3;
        private Label lblPackageNumber;
        private Label label2;
        private TextBox txtCity;
        private Button btnNext;
        private Button btnEdit;
        private Button btnRemove;
        private Button btnAdd;
        private Button btnScanNew;
        private Button btnBack;
        private TextBox txtZipCode;
        private Label label6;
        private ComboBox cmbState;
        private GroupBox groupBox2;
        private ListBox lstPackages;
        private ComboBox cmbViewPackage;
    }
}
