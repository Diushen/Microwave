﻿namespace SortingLists
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            lstSinOrdenar = new ListBox();
            lstOrdenada = new ListBox();
            button1 = new Button();
            button2 = new Button();
            btnAñadir1 = new Button();
            btnBorrarElemento1 = new Button();
            btnBorrarLista1 = new Button();
            btnAñadir2 = new Button();
            btnBorrarElemento2 = new Button();
            btnBorrarLista2 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(53, 35);
            label1.Name = "label1";
            label1.Size = new Size(155, 25);
            label1.TabIndex = 0;
            label1.Text = "Lista sin Ordenar";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(496, 35);
            label2.Name = "label2";
            label2.Size = new Size(140, 25);
            label2.TabIndex = 1;
            label2.Text = "Lista Ordenada";
            // 
            // lstSinOrdenar
            // 
            lstSinOrdenar.FormattingEnabled = true;
            lstSinOrdenar.ItemHeight = 15;
            lstSinOrdenar.Location = new Point(53, 63);
            lstSinOrdenar.Name = "lstSinOrdenar";
            lstSinOrdenar.Size = new Size(231, 454);
            lstSinOrdenar.TabIndex = 2;
            // 
            // lstOrdenada
            // 
            lstOrdenada.FormattingEnabled = true;
            lstOrdenada.ItemHeight = 15;
            lstOrdenada.Location = new Point(496, 63);
            lstOrdenada.Name = "lstOrdenada";
            lstOrdenada.SelectionMode = SelectionMode.MultiExtended;
            lstOrdenada.Size = new Size(231, 454);
            lstOrdenada.Sorted = true;
            lstOrdenada.TabIndex = 3;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(354, 132);
            button1.Name = "button1";
            button1.Size = new Size(73, 54);
            button1.TabIndex = 4;
            button1.Text = "<<";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(354, 240);
            button2.Name = "button2";
            button2.Size = new Size(73, 54);
            button2.TabIndex = 5;
            button2.Text = ">>";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // btnAñadir1
            // 
            btnAñadir1.Location = new Point(53, 547);
            btnAñadir1.Name = "btnAñadir1";
            btnAñadir1.Size = new Size(231, 30);
            btnAñadir1.TabIndex = 6;
            btnAñadir1.Text = "Añadir Elemento";
            btnAñadir1.UseVisualStyleBackColor = true;
            btnAñadir1.Click += button3_Click;
            // 
            // btnBorrarElemento1
            // 
            btnBorrarElemento1.Location = new Point(53, 612);
            btnBorrarElemento1.Name = "btnBorrarElemento1";
            btnBorrarElemento1.Size = new Size(231, 30);
            btnBorrarElemento1.TabIndex = 7;
            btnBorrarElemento1.Text = "Borrar Elemento";
            btnBorrarElemento1.UseVisualStyleBackColor = true;
            btnBorrarElemento1.Click += btnBorrarElemento1_Click;
            // 
            // btnBorrarLista1
            // 
            btnBorrarLista1.Location = new Point(53, 682);
            btnBorrarLista1.Name = "btnBorrarLista1";
            btnBorrarLista1.Size = new Size(231, 30);
            btnBorrarLista1.TabIndex = 8;
            btnBorrarLista1.Text = "Borrar Lista";
            btnBorrarLista1.UseVisualStyleBackColor = true;
            btnBorrarLista1.Click += btnBorrarLista1_Click;
            // 
            // btnAñadir2
            // 
            btnAñadir2.Location = new Point(496, 547);
            btnAñadir2.Name = "btnAñadir2";
            btnAñadir2.Size = new Size(231, 30);
            btnAñadir2.TabIndex = 9;
            btnAñadir2.Text = "Añadir Elemento";
            btnAñadir2.UseVisualStyleBackColor = true;
            btnAñadir2.Click += btnAñadir2_Click;
            // 
            // btnBorrarElemento2
            // 
            btnBorrarElemento2.Location = new Point(496, 612);
            btnBorrarElemento2.Name = "btnBorrarElemento2";
            btnBorrarElemento2.Size = new Size(231, 30);
            btnBorrarElemento2.TabIndex = 10;
            btnBorrarElemento2.Text = "Borrar Elementos";
            btnBorrarElemento2.UseVisualStyleBackColor = true;
            btnBorrarElemento2.Click += btnBorrarElemento2_Click;
            // 
            // btnBorrarLista2
            // 
            btnBorrarLista2.Location = new Point(496, 682);
            btnBorrarLista2.Name = "btnBorrarLista2";
            btnBorrarLista2.Size = new Size(231, 30);
            btnBorrarLista2.TabIndex = 11;
            btnBorrarLista2.Text = "Borrar Lista";
            btnBorrarLista2.UseVisualStyleBackColor = true;
            btnBorrarLista2.Click += btnBorrarLista2_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(920, 771);
            Controls.Add(btnBorrarLista2);
            Controls.Add(btnBorrarElemento2);
            Controls.Add(btnAñadir2);
            Controls.Add(btnBorrarLista1);
            Controls.Add(btnBorrarElemento1);
            Controls.Add(btnAñadir1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(lstOrdenada);
            Controls.Add(lstSinOrdenar);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private ListBox lstSinOrdenar;
        private ListBox lstOrdenada;
        private Button button1;
        private Button button2;
        private Button btnAñadir1;
        private Button btnBorrarElemento1;
        private Button btnBorrarLista1;
        private Button btnAñadir2;
        private Button btnBorrarElemento2;
        private Button btnBorrarLista2;
    }
}
