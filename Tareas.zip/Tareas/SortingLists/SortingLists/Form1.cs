using Microsoft.VisualBasic;
namespace SortingLists
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Crecion de arrays para la lista
        string[] parLista1 = { "Homero", "Shakespare", "Manzana", "Pera", "Escuela", "Colegio", "Computador", "Programacion", "Objeto", "Amanecer", "Terciopelo", "Babosa" };
        string[] parLista2 = { "Hechizo", "Sapito", "Ma�ana", "Zumba", "Estados", "Canada", "Karate", "Programacion", "Objeto", "Abedul", "Tercero", "Barriga" };

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < parLista1.Length; i++)
            {
                lstSinOrdenar.Items.Add(parLista1[i]);
            }
            for (int i = 0; i < parLista2.Length; i++)
            {
                lstOrdenada.Items.Add(parLista2[i]);
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string elementoParaLista = Interaction.InputBox("Escriba un elemento a agregar");
            lstSinOrdenar.Items.Add(elementoParaLista);
        }

        private void btnA�adir2_Click(object sender, EventArgs e)
        {
            string elementoParaLista = Interaction.InputBox("Escriba un elemento a agregar");
            lstOrdenada.Items.Add(elementoParaLista);
        }

        private void btnBorrarElemento1_Click(object sender, EventArgs e)
        {
            if (lstSinOrdenar.SelectedItem != null)
            {
                string elementoBorrar = lstSinOrdenar.SelectedItem.ToString();
                lstSinOrdenar.Items.Remove(elementoBorrar);
            }

        }

        private void btnBorrarElemento2_Click(object sender, EventArgs e)
        {

            for (int i = lstOrdenada.SelectedItems.Count - 1; i >= 0; i--)
            {
                lstOrdenada.Items.Remove(lstOrdenada.SelectedItems[i].ToString());
            }


        }

        private void btnBorrarLista1_Click(object sender, EventArgs e)
        {
            lstSinOrdenar.Items.Clear();
        }

        private void btnBorrarLista2_Click(object sender, EventArgs e)
        {
            lstOrdenada.Items.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (lstOrdenada.SelectedItems != null)
            {
                for (int i = 0; i < lstOrdenada.SelectedItems.Count; i++)
                {
                    lstSinOrdenar.Items.Add(lstOrdenada.SelectedItems[i]);
                }
                for (int i = lstOrdenada.SelectedItems.Count - 1; i >= 0; i--)
                {
                    lstOrdenada.Items.Remove(lstOrdenada.SelectedItems[i].ToString());
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (lstSinOrdenar.SelectedItem != null)
            {
                lstOrdenada.Items.Add(lstSinOrdenar.SelectedItem);
                lstSinOrdenar.Items.Remove(lstSinOrdenar.SelectedItem.ToString());
            }
        }
    }
}
