﻿namespace CommissionEmployee
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CommissionEmployeeClass commissionEmployee = new CommissionEmployeeClass("Jorge", "Perez", "001-0010102-1"
                , 5000.00M, 0.05M);


            Console.WriteLine(commissionEmployee.ToString());
            Console.WriteLine($"Employee Earning : {commissionEmployee.Earnings()}\n");

            BasePlusCommissionEmployee basePlusCommissionEmployee = new BasePlusCommissionEmployee
                (
                "Adela",
                "De los Santos",
                "002-01204560-4",
                5000.00M,
                0.05M,
                3000.00M
                );
            Console.WriteLine(basePlusCommissionEmployee);
            Console.WriteLine($"Employee Earning : {basePlusCommissionEmployee.Earnings()}\n");
        }
    }
}
