﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommissionEmployee
{
    internal class BasePlusCommissionEmployee : CommissionEmployeeClass
    {
        //Atributo salario base del empleado
        private decimal baseSalary;

        //propiedad para acceder al atributo
        public decimal BaseSalary
        {
            get { return baseSalary; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException(nameof(value),
                            value, $"{nameof(value)} Must be between 0 and 1"
                            );
                }
                else 
                {
                    baseSalary = value;
                }
            }
        }

        //Constructo de la clase
        public BasePlusCommissionEmployee(string firstName, string lastName, string cedula, decimal grossSales,
            decimal commissionRate, decimal baseSalary)
            : base(firstName, lastName, cedula, grossSales, commissionRate)
        {
            BaseSalary = baseSalary;
        }

        //Metodo para calcular las ganancias
        public override decimal Earnings() =>
            BaseSalary + (CommissionRate * GrossSales);

        //Version formateada del metodo ToString
        public override string ToString() =>
            $"Commission Employee with Base Salary: {Firstname} {Lastname}\n" +
            $"Id: {Cedula}\n" +
            $"Gross Sales: {GrossSales}\n" +
            $"Commission Rate: {CommissionRate}\n" +
            $"Earnings: {Earnings()}\n" +
            $"Base Salary: {BaseSalary}";
    }
}
