﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommissionEmployee
{
    internal class CommissionEmployeeClass
    {
        //Atributos del empleado con propiedades autogeneradas
        public string Firstname { get; set; }
        public string Lastname { get; set; }

        public string Cedula { get; set; }

        //Atributos para el salario y la tasa de comisiones
        private decimal grossSales;
        private decimal commissionRate;

        //Propiedades con accesos get y set
        public decimal GrossSales
        {
            get { return grossSales; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException(nameof(value),
                        value, $"{nameof(value)} Must be greater than zero"
                        );
                }
                else
                {
                    grossSales = value;
                }
            }
        }

        public decimal CommissionRate 
        {
            get { return commissionRate; }
            set 
            {
                if (value <= 0 || value >= 1)
                {
                    throw new ArgumentOutOfRangeException(nameof(value),
                            value, $"{nameof(value)} Must be between 0 and 1"
                            );
                }
                else 
                {
                    commissionRate = value;
                }
            }
        }

        //Constructor
        public CommissionEmployeeClass(string firstName, string lastName, string cedula, decimal grossSales, decimal commissionRate) 
        {
            Firstname = firstName;
            Lastname = lastName;
            Cedula = cedula;
            GrossSales = grossSales;
            CommissionRate = commissionRate;
        }

        //Metodo para calcular las ganancias del vendedor

        public virtual decimal Earnings() => CommissionRate * GrossSales;

        //Reescribir una representacion de cadena del metodo ToString
        public override string ToString() =>
            $"Commission Employee: {Firstname} {Lastname}\n" +
            $"Id: {Cedula}\n" +
            $"Gross Sales: {GrossSales}\n" +
            $"Commission Rate: {CommissionRate}\n" +
            $"Earnings: {Earnings()}\n";

    }
}
