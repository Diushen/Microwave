namespace StudentGradesApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Crear las variables que definen las columnas para 
        //Los nombres y sus promedios
        int campoNombre = 0;
        int campoPromedio = 1;

        //Variable que contenga la cantidad de estudiantes
        //que se introducen al programa
        int contadorEstudiantes = 0;

        //Para este ejemplo, asumiremos que el maximo de estudiantes
        //Permitidos es 10
        //Creamos un arreglo 10x2 para almacenar a los
        //Estudiantes
        string[,] estudiantes = new string[10, 2];

        //Metodo para calcular el promedio de un estudiante

        // modificador-acceso tipo-devuelto nombre-metodo <Lista de parametros>

        private double CalcularPromedioEstudiante(double test1, double test2, double test3)
        {
            return (test1 + test2 + test3) / 3.0;
        } // fin del metodo

        //Metodo para convertir un promedio numerico a letras
        string ConvertirGradoALetra(double grado)
        {
            if (grado >= 90)
            {
                return "A";
            }
            else if (grado >= 90)
            { return "B"; }
            else if (grado >= 70)
            { return "C"; }
            else
            {
                return "F";
            }
        }//Fin del metodo

        //Metodo para mostrar el promedio numerico de los estudiantes
        //Y de la clase completa
        void MostrarGradosNumericos()
        {
            lstResult.Items.Clear(); //Limpiar el listbox

            //Creamos una variable auxiliar para calcular el
            //Total de los promedios
            double total = 0;

            //Iterar sobre el arreglo de estudiantes
            for (int contador = 0; contador < contadorEstudiantes; contador++)
            {
                //Mostrar cada estudiante y su promedio en el lstResult
                lstResult.Items.Add(estudiantes[contador, campoNombre] + "\t" + estudiantes[contador, campoPromedio]);
                //acumular los promedios
                total += Convert.ToDouble(estudiantes[contador, campoPromedio]);
            }

            //Mostrar el promedio de la clases
            txtClassAverage.Text = string.Format("{0:F}", total / contadorEstudiantes);

        }

        //Metodo para mostrar las calificaciones de los estudiantes como letras
        //Y el promedio total de la clase como letra

        void MostrarGradosLetras()
        {
            lstResult.Items.Clear();
            double total = 0;

            //iteramos sobre el arreglo de estudiantes para mostrarlos en el 
            //lstResult y acumular cada promedio

            for (int contador = 0; contador < contadorEstudiantes; contador++)
            {
                lstResult.Items.Add(estudiantes[contador, campoNombre] + "\t" + ConvertirGradoALetra(Convert.ToDouble(estudiantes[contador, campoPromedio])));
            //Acumulamos el promedio
                total += double.Parse(estudiantes[contador, campoPromedio]);
            }

            txtClassAverage.Text = string.Format("{0:F}", ConvertirGradoALetra(total / contadorEstudiantes));
        }//fin del metodo

        private void button1_Click(object sender, EventArgs e)
        {
            //Obtener los valores de los campos de entrada
            double test1 = double.Parse(txtTest1.Text);
            double test2 = double.Parse(txtTest2.Text);
            double test3 = double.Parse(txtTest3.Text);

            string studentNmae = txtStudentName.Text;

            if (contadorEstudiantes > 10)
            {
                btnCalculate.Enabled = false;
            }
            else 
            {
                //Anadir el estudiante al arreglo
                estudiantes[contadorEstudiantes, campoNombre] = studentNmae;
                estudiantes[contadorEstudiantes, campoPromedio] = CalcularPromedioEstudiante(test1, test2, test3).ToString("F");
                contadorEstudiantes++;
            }
            
                
  

            if (rbnNumeric.Checked)
            {
                MostrarGradosNumericos();
            }
            else
            {
                MostrarGradosLetras();
            }

            //limpiar los campos de entrada

            txtStudentName.Clear();
            txtTest1.Clear();
            txtTest2.Clear();
            txtTest3.Clear();

        }

        private void rbnNumeric_CheckedChanged(object sender, EventArgs e)
        {
            MostrarGradosNumericos();
        }

        private void rbnLetter_CheckedChanged(object sender, EventArgs e)
        {
            MostrarGradosLetras();
        }
    }
}
