﻿namespace StudentGradesApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            txtTest3 = new TextBox();
            txtTest2 = new TextBox();
            txtTest1 = new TextBox();
            txtStudentName = new TextBox();
            groupBox2 = new GroupBox();
            rbnLetter = new RadioButton();
            rbnNumeric = new RadioButton();
            btnCalculate = new Button();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            lstResult = new ListBox();
            label5 = new Label();
            txtClassAverage = new TextBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtTest3);
            groupBox1.Controls.Add(txtTest2);
            groupBox1.Controls.Add(txtTest1);
            groupBox1.Controls.Add(txtStudentName);
            groupBox1.Controls.Add(groupBox2);
            groupBox1.Controls.Add(btnCalculate);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(38, 32);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(394, 406);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            // 
            // txtTest3
            // 
            txtTest3.Location = new Point(174, 200);
            txtTest3.Name = "txtTest3";
            txtTest3.Size = new Size(100, 23);
            txtTest3.TabIndex = 10;
            // 
            // txtTest2
            // 
            txtTest2.Location = new Point(174, 155);
            txtTest2.Name = "txtTest2";
            txtTest2.Size = new Size(100, 23);
            txtTest2.TabIndex = 9;
            // 
            // txtTest1
            // 
            txtTest1.Location = new Point(174, 112);
            txtTest1.Name = "txtTest1";
            txtTest1.Size = new Size(100, 23);
            txtTest1.TabIndex = 8;
            // 
            // txtStudentName
            // 
            txtStudentName.Location = new Point(122, 41);
            txtStudentName.Name = "txtStudentName";
            txtStudentName.Size = new Size(232, 23);
            txtStudentName.TabIndex = 7;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(rbnLetter);
            groupBox2.Controls.Add(rbnNumeric);
            groupBox2.Location = new Point(33, 328);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(332, 56);
            groupBox2.TabIndex = 6;
            groupBox2.TabStop = false;
            groupBox2.Text = "View";
            // 
            // rbnLetter
            // 
            rbnLetter.AutoSize = true;
            rbnLetter.Location = new Point(161, 22);
            rbnLetter.Name = "rbnLetter";
            rbnLetter.Size = new Size(55, 19);
            rbnLetter.TabIndex = 1;
            rbnLetter.TabStop = true;
            rbnLetter.Text = "Letter";
            rbnLetter.UseVisualStyleBackColor = true;
            rbnLetter.CheckedChanged += rbnLetter_CheckedChanged;
            // 
            // rbnNumeric
            // 
            rbnNumeric.AutoSize = true;
            rbnNumeric.Location = new Point(22, 22);
            rbnNumeric.Name = "rbnNumeric";
            rbnNumeric.Size = new Size(71, 19);
            rbnNumeric.TabIndex = 0;
            rbnNumeric.TabStop = true;
            rbnNumeric.Text = "Numeric";
            rbnNumeric.UseVisualStyleBackColor = true;
            rbnNumeric.CheckedChanged += rbnNumeric_CheckedChanged;
            // 
            // btnCalculate
            // 
            btnCalculate.Location = new Point(167, 252);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(107, 37);
            btnCalculate.TabIndex = 5;
            btnCalculate.Text = "Student Grade";
            btnCalculate.UseVisualStyleBackColor = true;
            btnCalculate.Click += button1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(19, 208);
            label4.Name = "label4";
            label4.Size = new Size(36, 15);
            label4.TabIndex = 4;
            label4.Text = "Test 3";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(19, 163);
            label3.Name = "label3";
            label3.Size = new Size(36, 15);
            label3.TabIndex = 3;
            label3.Text = "Test 2";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(19, 120);
            label2.Name = "label2";
            label2.Size = new Size(36, 15);
            label2.TabIndex = 2;
            label2.Text = "Test 1";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(19, 44);
            label1.Name = "label1";
            label1.Size = new Size(91, 15);
            label1.TabIndex = 1;
            label1.Text = "Student's Name";
            // 
            // lstResult
            // 
            lstResult.FormattingEnabled = true;
            lstResult.ItemHeight = 15;
            lstResult.Location = new Point(541, 32);
            lstResult.Name = "lstResult";
            lstResult.Size = new Size(447, 304);
            lstResult.TabIndex = 1;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(541, 386);
            label5.Name = "label5";
            label5.Size = new Size(83, 15);
            label5.TabIndex = 2;
            label5.Text = "Class Average:";
            // 
            // txtClassAverage
            // 
            txtClassAverage.Location = new Point(735, 376);
            txtClassAverage.Name = "txtClassAverage";
            txtClassAverage.Size = new Size(100, 23);
            txtClassAverage.TabIndex = 3;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1089, 450);
            Controls.Add(txtClassAverage);
            Controls.Add(label5);
            Controls.Add(lstResult);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Student's Grades App";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private Label label2;
        private Label label1;
        private TextBox txtTest3;
        private TextBox txtTest2;
        private TextBox txtTest1;
        private TextBox txtStudentName;
        private GroupBox groupBox2;
        private RadioButton rbnLetter;
        private RadioButton rbnNumeric;
        private Button btnCalculate;
        private Label label4;
        private Label label3;
        private ListBox lstResult;
        private Label label5;
        private TextBox txtClassAverage;
    }
}
